package com.project.learning;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	WebDriver driver;
	
	By user = By.id("username");
	By pwd = By.id("password");
	By loginbtn = By.id("submit");
	By successMessage = By.tagName("h1");
	By errorMessage = By.id("error");
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void PageNavigate() {
		driver.get("https://practicetestautomation.com/practice-test-login/");
	}
	
	public void login(String name, String pass) {
		driver.findElement(user).clear();
		driver.findElement(user).sendKeys(name);
		driver.findElement(pwd).clear();
		driver.findElement(pwd).sendKeys(pass);
		driver.findElement(loginbtn).click();
	}
	
	public String getSuccessMsg() {
		String msg = driver.findElement(successMessage).getText();
		return msg;
	}
	
	public String getErrorMsg() {
		String err = driver.findElement(errorMessage).getText();
		return err;
	}
	
	
	
	
}
