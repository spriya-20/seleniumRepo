package com.project.learning;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {
	
	@DataProvider(name = "loginData")
	public Object[][] loginData() {
		return new Object[][] {
			{"student", "Password123", "success"},{"student","wrongpwd", "error"},{"wronguser","Password123","error"}
		};
	}
	
	@Test(dataProvider = "loginData")
	public void testLogin(String username, String password, String expectedOutcome) {
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.PageNavigate();
		loginPage.login(username, password);
		if(expectedOutcome.equals("success")) {
			Assert.assertTrue(loginPage.getSuccessMsg().contains("Logged In Successfully"), "Logged In Successfully");
		}
		else {
			Assert.assertTrue(loginPage.getErrorMsg().contains("Your username is invalid!") ||
                    loginPage.getErrorMsg().contains("Your password is invalid!"), "Error message not as expected.");
		}
	}
}
